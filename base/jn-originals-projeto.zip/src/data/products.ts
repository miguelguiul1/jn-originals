const files = import.meta.glob("../assets/img/*.jpg", {
  eager: true,
  query: "?url",
  import: "default",
}) as Record<string, string>;

/** Resolve o nome curto da imagem (ex.: "nike") para a URL final. */
export const imgUrl = (name: string) => files[`../assets/img/${name}.jpg`];

export type CategoryId =
  | "calcados"
  | "calcas"
  | "polos"
  | "jaquetas"
  | "conjuntos"
  | "acessorios";

export interface Category {
  id: CategoryId;
  label: string;
}

export const categories: Category[] = [
  { id: "calcados", label: "Calçados" },
  { id: "polos", label: "Camisas polo" },
  { id: "jaquetas", label: "Jaquetas e blusões" },
  { id: "calcas", label: "Calças" },
  { id: "conjuntos", label: "Conjuntos" },
  { id: "acessorios", label: "Acessórios" },
];

export interface Product {
  slug: string;
  name: string;
  brand: string;
  category: CategoryId;
  code: string;
  price: number;
  oldPrice?: number;
  /** valor da parcela (12x) exatamente como aparece no site atual */
  installment: number;
  image: string;
  sizes: string[];
  isNew?: boolean;
}

const shoe = ["38", "39", "40", "41", "42", "43", "44"];
const pants = ["38", "40", "42", "44", "46"];
const tops = ["P", "M", "G", "GG"];

// Preços, códigos e parcelas copiados do site atual (jnoriginalsshop.com.br).
// Tamanhos são exemplo: trocar pelo estoque real.
export const products: Product[] = [
  {
    slug: "tenis-nike-court-borough-low-bball",
    name: "Tênis Nike Court Borough Low BBall",
    brand: "Nike",
    category: "calcados",
    code: "IR6452-101",
    price: 450,
    installment: 48.7,
    image: "nike",
    sizes: shoe,
    isNew: true,
  },
  {
    slug: "polo-tommy-hilfiger-letreiro-navy-white",
    name: "Polo Tommy Hilfiger Letreiro Navy Blue/White",
    brand: "Tommy Hilfiger",
    category: "polos",
    code: "Navy Blue / White",
    price: 499,
    installment: 54,
    image: "polo",
    sizes: tops,
    isNew: true,
  },
  {
    slug: "moletom-tommy-hilfiger-1-4-ziper-azul-royal",
    name: "Moletom 1/4 Ziper Tommy Hilfiger Azul Royal",
    brand: "Tommy Hilfiger",
    category: "jaquetas",
    code: "Azul Royal",
    price: 700,
    installment: 75.76,
    image: "moletom",
    sizes: tops,
  },
  {
    slug: "conjunto-tommy-hilfiger-half-zip-azul-marinho",
    name: "Conjunto Tommy Hilfiger Half Zip Azul Marinho",
    brand: "Tommy Hilfiger",
    category: "conjuntos",
    code: "MWOMW46697-DW5",
    price: 1599,
    installment: 173.06,
    image: "conjunto",
    sizes: tops,
  },
  {
    slug: "jaqueta-adidas-track-argentina-afa",
    name: "Jaqueta Adidas Track Argentina AFA",
    brand: "Adidas",
    category: "jaquetas",
    code: "AFA",
    price: 380,
    installment: 41.12,
    image: "jaqueta",
    sizes: tops,
    isNew: true,
  },
  {
    slug: "bone-puma-bmw-2026-preto",
    name: "Boné Puma BMW 2026 Preto",
    brand: "Puma",
    category: "acessorios",
    code: "027317-01",
    price: 200,
    installment: 21.64,
    image: "bone",
    sizes: ["Único"],
  },
  {
    slug: "calca-tetch-stretch-all-black",
    name: "Calça Tetch Stretch All Black",
    brand: "Tetch",
    category: "calcas",
    code: "All Black",
    price: 130,
    oldPrice: 190,
    installment: 14.07,
    image: "tetch",
    sizes: pants,
  },
  {
    slug: "calca-preta-lisa-uni-jeans-0004",
    name: "Calça Preta Lisa Uni Jeans",
    brand: "Uni Jeans",
    category: "calcas",
    code: "0004",
    price: 130,
    installment: 14.07,
    image: "calca-preta",
    sizes: pants,
  },
];

export const brands = Array.from(new Set(products.map((p) => p.brand)));

export const getProduct = (slug: string) =>
  products.find((p) => p.slug === slug);

export const discountPct = (p: Product) =>
  p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
