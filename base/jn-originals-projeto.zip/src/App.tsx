import { useEffect } from "react";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import { CartProvider } from "./lib/cart";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { CartDrawer } from "./components/CartDrawer";
import { Intro } from "./components/Intro";
import Home from "./pages/Home";
import Catalog from "./pages/Catalog";
import Product from "./pages/Product";
import Checkout from "./pages/Checkout";
import HowToBuy from "./pages/HowToBuy";
import Store from "./pages/Store";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <HashRouter>
      <CartProvider>
        <ScrollToTop />
        <Intro />
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/loja" element={<Catalog />} />
            <Route path="/produto/:slug" element={<Product />} />
            <Route path="/finalizar" element={<Checkout />} />
            <Route path="/como-comprar" element={<HowToBuy />} />
            <Route path="/a-loja" element={<Store />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
        <CartDrawer />
      </CartProvider>
    </HashRouter>
  );
}
