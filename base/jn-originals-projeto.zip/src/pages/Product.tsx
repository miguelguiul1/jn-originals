import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ProductCard } from "../components/ProductCard";
import {
  categories,
  discountPct,
  getProduct,
  imgUrl,
  products,
} from "../data/products";
import { useCart } from "../lib/cart";
import { STORE, contactLabel, contactUrl, money } from "../lib/store";

export default function Product() {
  const { slug = "" } = useParams();
  const p = getProduct(slug);
  const { add } = useCart();
  const [size, setSize] = useState("");
  const [warn, setWarn] = useState(false);

  if (!p) {
    return (
      <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-8">
        <p className="display text-6xl">Produto não encontrado.</p>
        <Link to="/loja" className="mt-6 inline-block underline underline-offset-4">
          Voltar para a loja
        </Link>
      </div>
    );
  }

  const off = discountPct(p);
  const catLabel = categories.find((c) => c.id === p.category)?.label;
  const related = products.filter((x) => x.slug !== p.slug).slice(0, 4);

  const onAdd = () => {
    if (!size) {
      setWarn(true);
      return;
    }
    add(p.slug, size);
  };

  return (
    <div className="mx-auto max-w-[1400px] px-5 pb-8 pt-6 md:px-8 md:pt-10">
      <nav className="mono text-[11px] uppercase tracking-[0.16em] text-stone">
        <Link to="/loja" className="hover:text-ink">
          Loja
        </Link>{" "}
        /{" "}
        <Link to={`/loja?cat=${p.category}`} className="hover:text-ink">
          {catLabel}
        </Link>
      </nav>

      <div className="mt-5 grid gap-8 md:grid-cols-[1.15fr_1fr] md:gap-14">
        <div className="relative bg-bone md:sticky md:top-24 md:self-start">
          <img
            src={imgUrl(p.image)}
            alt={p.name}
            className="aspect-[4/5] w-full object-cover"
          />
          {off > 0 && (
            <span className="mono absolute left-0 top-0 bg-signal px-3 py-1.5 text-xs text-paper">
              −{off}%
            </span>
          )}
        </div>

        <div>
          <p className="mono text-[12px] uppercase tracking-[0.18em] text-stone">
            {p.brand} · {p.code}
          </p>
          <h1 className="display mt-3 text-[clamp(2.8rem,7vw,5.4rem)]">
            {p.name}
          </h1>

          <div className="mt-6 flex items-baseline gap-3">
            <span className="mono text-3xl font-semibold">{money(p.price)}</span>
            {p.oldPrice && (
              <span className="mono text-base text-stone line-through">
                {money(p.oldPrice)}
              </span>
            )}
          </div>
          <p className="mono mt-1 text-[13px] text-stone">
            ou 12x de {money(p.installment)} no cartão · Pix
          </p>

          <div className="mt-8">
            <div className="flex items-baseline justify-between">
              <span className="text-[12px] uppercase tracking-[0.18em]">
                Tamanho
              </span>
              {warn && !size && (
                <span className="text-[12px] text-signal">Escolha um tamanho</span>
              )}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {p.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setSize(s);
                    setWarn(false);
                  }}
                  aria-pressed={size === s}
                  className={`mono h-11 min-w-[3.1rem] border rule px-3 text-[14px] transition-colors ${
                    size === s ? "bg-ink text-paper" : "hover:bg-bone"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={onAdd}
            className="mt-8 w-full bg-ink py-4 text-[13px] uppercase tracking-[0.22em] text-paper transition-colors hover:bg-signal"
          >
            Adicionar à sacola
          </button>
          <a
            href={contactUrl(`Oi! Tenho interesse neste produto: ${p.name} (${p.code}).`)}
            target="_blank"
            rel="noreferrer"
            className="mt-3 block w-full border rule py-4 text-center text-[13px] uppercase tracking-[0.22em] transition-colors hover:bg-ink hover:text-paper"
          >
            Perguntar no {contactLabel}
          </a>

          <ul className="mt-10 divide-y divide-ink/15 border-y rule text-[15px]">
            {[
              ["Original", "Apenas produtos originais."],
              ["Entrega", "Motoboy em São Paulo, pagamento no ato da entrega."],
              ["Retirada", `Na loja, ${STORE.address}.`],
            ].map(([t, d]) => (
              <li key={t} className="flex gap-4 py-4">
                <span className="mono w-20 shrink-0 text-[11px] uppercase tracking-wider text-stone">
                  {t}
                </span>
                <span>{d}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <section className="pt-20 md:pt-28">
        <h2 className="display text-[clamp(2.4rem,6vw,4.2rem)]">
          Combina <span className="italic">com</span>
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
          {related.map((r) => (
            <ProductCard key={r.slug} p={r} />
          ))}
        </div>
      </section>
    </div>
  );
}
