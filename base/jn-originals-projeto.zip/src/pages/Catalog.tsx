import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { ProductCard } from "../components/ProductCard";
import { brands, categories, products } from "../data/products";

type Sort = "novos" | "menor" | "maior";

export default function Catalog() {
  const [params, setParams] = useSearchParams();
  const cat = params.get("cat") ?? "";
  const brand = params.get("marca") ?? "";
  const q = params.get("q") ?? "";
  const sort = (params.get("ord") as Sort) || "novos";

  const set = (k: string, v: string) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    setParams(next, { replace: true });
  };

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    let r = products.filter(
      (p) =>
        (!cat || p.category === cat) &&
        (!brand || p.brand === brand) &&
        (!term ||
          `${p.name} ${p.brand} ${p.code}`.toLowerCase().includes(term)),
    );
    if (sort === "menor") r = [...r].sort((a, b) => a.price - b.price);
    if (sort === "maior") r = [...r].sort((a, b) => b.price - a.price);
    return r;
  }, [cat, brand, q, sort]);

  const title = categories.find((c) => c.id === cat)?.label ?? "Todos os produtos";

  const chip = (active: boolean) =>
    `border rule px-4 py-2 text-[12px] uppercase tracking-[0.16em] transition-colors ${
      active ? "bg-ink text-paper" : "hover:bg-bone"
    }`;

  return (
    <div className="mx-auto max-w-[1400px] px-5 pb-8 pt-10 md:px-8 md:pt-16">
      <p className="mono text-[12px] uppercase tracking-[0.2em] text-stone">
        Loja
      </p>
      <h1 className="display mt-2 text-[clamp(3.4rem,12vw,9rem)]">{title}</h1>

      <div className="mt-8 flex flex-col gap-4 border-y rule py-5 md:flex-row md:items-center md:justify-between">
        <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 md:mx-0 md:flex-wrap md:px-0">
          <button className={chip(!cat)} onClick={() => set("cat", "")}>
            Tudo
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              className={`${chip(cat === c.id)} shrink-0`}
              onClick={() => set("cat", c.id)}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <select
            aria-label="Marca"
            value={brand}
            onChange={(e) => set("marca", e.target.value)}
            className="h-10 flex-1 border rule bg-paper px-3 text-[13px] md:flex-none"
          >
            <option value="">Todas as marcas</option>
            {brands.map((b) => (
              <option key={b}>{b}</option>
            ))}
          </select>
          <select
            aria-label="Ordenar"
            value={sort}
            onChange={(e) => set("ord", e.target.value === "novos" ? "" : e.target.value)}
            className="h-10 flex-1 border rule bg-paper px-3 text-[13px] md:flex-none"
          >
            <option value="novos">Em destaque</option>
            <option value="menor">Menor preço</option>
            <option value="maior">Maior preço</option>
          </select>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between gap-4">
        <input
          type="search"
          value={q}
          onChange={(e) => set("q", e.target.value)}
          placeholder="Buscar por nome, marca ou código"
          className="h-11 w-full max-w-sm border-b rule bg-transparent text-[15px] outline-none placeholder:text-stone"
        />
        <span className="mono shrink-0 text-[12px] text-stone">
          {list.length} {list.length === 1 ? "produto" : "produtos"}
        </span>
      </div>

      {list.length === 0 ? (
        <div className="py-24">
          <p className="display text-5xl">Nada por aqui.</p>
          <p className="mt-3 text-stone">Tente outra categoria ou limpe a busca.</p>
          <button
            onClick={() => setParams({}, { replace: true })}
            className="mt-6 border rule px-6 py-3 text-[13px] uppercase tracking-[0.18em] hover:bg-ink hover:text-paper"
          >
            Limpar filtros
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
          {list.map((p) => (
            <ProductCard key={p.slug} p={p} />
          ))}
        </div>
      )}
    </div>
  );
}
