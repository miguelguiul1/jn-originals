import { Link } from "react-router-dom";
import { STORE, contactLabel, contactUrl } from "../lib/store";

const steps = [
  {
    t: "Escolha",
    d: "Navegue pela loja, abra o produto e selecione o tamanho. Em dúvida de numeração ou disponibilidade, chame a loja.",
  },
  {
    t: "Feche o pedido",
    d: "Adicione à sacola, informe seus dados e escolha entrega por motoboy ou retirada na loja.",
  },
  {
    t: "Confirme",
    d: "A loja confirma o pedido e combina os detalhes da entrega com você.",
  },
  {
    t: "Receba e pague",
    d: "Nas entregas por motoboy você paga no ato, só quando receber. Também aceitamos Pix e cartão em até 12x.",
  },
];

const faq = [
  [
    "O produto é original?",
    "Sim. A JN trabalha apenas com produtos originais, e a ficha de cada item mostra marca, modelo e código.",
  ],
  [
    "Quais as formas de pagamento?",
    "Pix, cartão em até 12x e, nas entregas por motoboy, pagamento no ato da entrega.",
  ],
  [
    "Posso retirar na loja?",
    `Pode. Fica na ${STORE.address}, ${STORE.city}. ${STORE.hours}.`,
  ],
  [
    "Como sei se tem o meu tamanho?",
    `Pergunte pelo ${contactLabel} direto na página do produto. A loja responde com a disponibilidade.`,
  ],
];

export default function HowToBuy() {
  return (
    <div className="mx-auto max-w-[1400px] px-5 pb-8 pt-10 md:px-8 md:pt-16">
      <p className="mono text-[12px] uppercase tracking-[0.2em] text-stone">Ajuda</p>
      <h1 className="display mt-2 text-[clamp(3.4rem,13vw,10rem)]">
        Como <span className="italic text-signal">comprar</span>
      </h1>

      <ol className="mt-12 border-t rule">
        {steps.map((s, i) => (
          <li
            key={s.t}
            className="grid gap-3 border-b rule py-8 md:grid-cols-[120px_1fr_1.2fr] md:items-baseline md:gap-8"
          >
            <span className="display text-6xl text-stone md:text-7xl">
              {String(i + 1).padStart(2, "0")}
            </span>
            <h2 className="display text-[2.6rem]">{s.t}</h2>
            <p className="max-w-md text-[16px] leading-relaxed text-ink/75">{s.d}</p>
          </li>
        ))}
      </ol>

      <section className="mt-20 grid gap-10 md:grid-cols-[1fr_1.6fr]">
        <h2 className="display text-[clamp(2.6rem,7vw,5rem)]">Perguntas</h2>
        <dl className="divide-y divide-ink/15 border-y rule">
          {faq.map(([q, a]) => (
            <div key={q} className="py-6">
              <dt className="text-[17px] font-semibold">{q}</dt>
              <dd className="mt-2 max-w-xl text-[15px] leading-relaxed text-ink/70">{a}</dd>
            </div>
          ))}
        </dl>
      </section>

      <div className="mt-16 flex flex-wrap items-center gap-4 bg-ink p-7 text-paper md:p-10">
        <p className="display flex-1 text-[2.4rem]">Ainda com dúvida?</p>
        <a
          href={contactUrl("Oi! Tenho uma dúvida sobre como comprar.")}
          target="_blank"
          rel="noreferrer"
          className="bg-paper px-7 py-4 text-[13px] uppercase tracking-[0.2em] text-ink hover:bg-signal hover:text-paper"
        >
          Falar no {contactLabel}
        </a>
        <Link
          to="/loja"
          className="border border-paper/60 px-7 py-4 text-[13px] uppercase tracking-[0.2em] hover:bg-paper hover:text-ink"
        >
          Ver a loja
        </Link>
      </div>
    </div>
  );
}
