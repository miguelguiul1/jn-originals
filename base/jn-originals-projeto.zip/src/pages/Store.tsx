import { brands } from "../data/products";
import { STORE, contactLabel, contactUrl, mapsUrl } from "../lib/store";

export default function Store() {
  return (
    <div className="mx-auto max-w-[1400px] px-5 pb-8 pt-10 md:px-8 md:pt-16">
      <p className="mono text-[12px] uppercase tracking-[0.2em] text-stone">A loja</p>
      <h1 className="display mt-2 text-[clamp(3.6rem,14vw,11rem)]">
        Feita pra quem
        <br />
        <span className="italic text-signal">curte o original.</span>
      </h1>

      <div className="mt-14 grid gap-12 md:grid-cols-2 md:gap-20">
        <div className="space-y-5 text-[17px] leading-relaxed text-ink/80">
          <p>
            A JN Originals vende roupas, tênis e acessórios de marca, sempre
            originais. Atende na loja física e on-line, e acompanha cada
            lançamento no Instagram, onde reúne 198 mil seguidores.
          </p>
          <p>
            Trabalha com marcas como {brands.filter((b) => b !== "Tetch" && b !== "Uni Jeans").join(", ")}.
            Quem não pode passar na loja recebe por motoboy e paga só quando
            o pedido chega.
          </p>
        </div>

        <dl className="divide-y divide-ink/15 border-y rule text-[16px]">
          {[
            ["Endereço", `${STORE.address}, ${STORE.city}`],
            ["Horário", STORE.hours],
            ["Empresa", `${STORE.legalName} · CNPJ ${STORE.cnpj}`],
            ["Instagram", `@${STORE.instagram}`],
          ].map(([k, v]) => (
            <div key={k} className="flex gap-6 py-4">
              <dt className="mono w-24 shrink-0 text-[11px] uppercase tracking-wider text-stone">
                {k}
              </dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="mt-12 flex flex-wrap gap-3">
        <a
          href={mapsUrl}
          target="_blank"
          rel="noreferrer"
          className="bg-ink px-7 py-4 text-[13px] uppercase tracking-[0.2em] text-paper hover:bg-signal"
        >
          Como chegar
        </a>
        <a
          href={contactUrl("Oi! Vim pelo site da JN Originals.")}
          target="_blank"
          rel="noreferrer"
          className="border rule px-7 py-4 text-[13px] uppercase tracking-[0.2em] hover:bg-ink hover:text-paper"
        >
          Falar no {contactLabel}
        </a>
        <a
          href={STORE.instagramUrl}
          target="_blank"
          rel="noreferrer"
          className="border rule px-7 py-4 text-[13px] uppercase tracking-[0.2em] hover:bg-ink hover:text-paper"
        >
          Instagram
        </a>
      </div>
    </div>
  );
}
