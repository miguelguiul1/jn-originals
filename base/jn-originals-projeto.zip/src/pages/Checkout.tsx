import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { imgUrl } from "../data/products";
import { useCart, type CartLine } from "../lib/cart";
import { STORE, contactLabel, contactUrl, money } from "../lib/store";
import type { Product } from "../data/products";

type Delivery = "motoboy" | "retirada";
type Pay = "pix" | "cartao" | "entrega";

interface Done {
  id: string;
  lines: (CartLine & { product: Product })[];
  total: number;
  name: string;
  delivery: Delivery;
  pay: Pay;
}

const payLabel: Record<Pay, string> = {
  pix: "Pix",
  cartao: "Cartão em até 12x",
  entrega: "Pagar na entrega",
};

const field =
  "h-12 w-full border rule bg-transparent px-3 text-[15px] outline-none focus:bg-bone/60";
const label = "mb-1.5 block text-[11px] uppercase tracking-[0.18em]";

export default function Checkout() {
  const { lines, subtotal, clear } = useCart();
  const [delivery, setDelivery] = useState<Delivery>("motoboy");
  const [pay, setPay] = useState<Pay>("pix");
  const [done, setDone] = useState<Done | null>(null);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setDone({
      id: "JN-" + Date.now().toString(36).toUpperCase().slice(-5),
      lines,
      total: subtotal,
      name: String(fd.get("nome") ?? ""),
      delivery,
      pay: delivery === "retirada" && pay === "entrega" ? "pix" : pay,
    });
    clear();
    window.scrollTo({ top: 0 });
  };

  if (done) {
    const msg =
      `Oi! Fiz o pedido ${done.id} no site.\n\n` +
      done.lines
        .map(
          (l) =>
            `• ${l.qty}x ${l.product.name} (tam. ${l.size}) — ${money(l.product.price * l.qty)}`,
        )
        .join("\n") +
      `\n\nTotal: ${money(done.total)}\n` +
      `${done.delivery === "motoboy" ? "Entrega por motoboy" : "Retirada na loja"} · ${payLabel[done.pay]}\n` +
      `Nome: ${done.name}`;
    return (
      <div className="mx-auto max-w-[900px] px-5 py-16 md:px-8 md:py-24">
        <p className="mono text-[12px] uppercase tracking-[0.2em] text-signal">
          Pedido de demonstração · {done.id}
        </p>
        <h1 className="display mt-3 text-[clamp(3.4rem,12vw,8rem)]">
          Pedido <span className="italic">recebido.</span>
        </h1>
        <p className="mt-5 max-w-xl text-[17px] leading-relaxed text-ink/75">
          Aqui a loja confirmaria o pedido e combinaria a entrega. Como este é
          um protótipo, nada foi enviado nem cobrado. Use o botão abaixo para
          ver como o pedido chegaria no {contactLabel} da JN.
        </p>

        <ul className="mt-10 divide-y divide-ink/15 border-y rule">
          {done.lines.map((l) => (
            <li key={l.slug + l.size} className="flex justify-between gap-4 py-4 text-[15px]">
              <span>
                {l.qty}x {l.product.name}{" "}
                <span className="mono text-stone">· tam. {l.size}</span>
              </span>
              <span className="mono">{money(l.product.price * l.qty)}</span>
            </li>
          ))}
          <li className="flex justify-between py-4">
            <span className="text-[13px] uppercase tracking-[0.18em]">Total</span>
            <span className="mono text-xl font-semibold">{money(done.total)}</span>
          </li>
        </ul>

        <div className="mt-8 flex flex-wrap gap-3">
          <a
            href={contactUrl(msg)}
            target="_blank"
            rel="noreferrer"
            className="bg-ink px-7 py-4 text-[13px] uppercase tracking-[0.2em] text-paper transition-colors hover:bg-signal"
          >
            Enviar pedido no {contactLabel}
          </a>
          <Link
            to="/loja"
            className="border rule px-7 py-4 text-[13px] uppercase tracking-[0.2em] hover:bg-ink hover:text-paper"
          >
            Continuar comprando
          </Link>
        </div>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-[900px] px-5 py-24 md:px-8">
        <p className="display text-[clamp(3.4rem,12vw,8rem)]">Sacola vazia.</p>
        <Link
          to="/loja"
          className="mt-8 inline-block bg-ink px-7 py-4 text-[13px] uppercase tracking-[0.2em] text-paper"
        >
          Ver a loja
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-5 pb-8 pt-10 md:px-8 md:pt-16">
      <h1 className="display text-[clamp(3.4rem,12vw,8rem)]">Finalizar pedido</h1>
      <p className="mono mt-3 inline-block bg-signal px-3 py-1.5 text-[11px] uppercase tracking-[0.14em] text-paper">
        Demonstração · nenhum pagamento é processado
      </p>

      <form
        onSubmit={onSubmit}
        className="mt-10 grid gap-12 md:grid-cols-[1.3fr_1fr] md:gap-16"
      >
        <div className="space-y-10">
          <fieldset>
            <legend className="display text-3xl">01 Seus dados</legend>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <div className="md:col-span-2">
                <label className={label} htmlFor="nome">Nome completo</label>
                <input id="nome" name="nome" required autoComplete="name" className={field} />
              </div>
              <div>
                <label className={label} htmlFor="tel">WhatsApp</label>
                <input id="tel" name="tel" required inputMode="tel" autoComplete="tel" placeholder="(11) 99999-9999" className={field} />
              </div>
              <div>
                <label className={label} htmlFor="email">E-mail (opcional)</label>
                <input id="email" name="email" type="email" autoComplete="email" className={field} />
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend className="display text-3xl">02 Entrega</legend>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {(
                [
                  ["motoboy", "Motoboy", "Valor combinado com a loja"],
                  ["retirada", "Retirar na loja", STORE.address],
                ] as const
              ).map(([v, t, d]) => (
                <button
                  type="button"
                  key={v}
                  onClick={() => setDelivery(v)}
                  aria-pressed={delivery === v}
                  className={`border rule p-4 text-left transition-colors ${
                    delivery === v ? "bg-ink text-paper" : "hover:bg-bone"
                  }`}
                >
                  <span className="block text-[15px] font-medium">{t}</span>
                  <span className={`mono block text-[12px] ${delivery === v ? "text-paper/70" : "text-stone"}`}>
                    {d}
                  </span>
                </button>
              ))}
            </div>

            {delivery === "motoboy" && (
              <div className="mt-5 grid gap-4 md:grid-cols-6">
                <div className="md:col-span-2">
                  <label className={label} htmlFor="cep">CEP</label>
                  <input id="cep" name="cep" required inputMode="numeric" autoComplete="postal-code" className={field} />
                </div>
                <div className="md:col-span-3">
                  <label className={label} htmlFor="rua">Rua</label>
                  <input id="rua" name="rua" required autoComplete="address-line1" className={field} />
                </div>
                <div>
                  <label className={label} htmlFor="num">Nº</label>
                  <input id="num" name="num" required className={field} />
                </div>
                <div className="md:col-span-3">
                  <label className={label} htmlFor="bairro">Bairro</label>
                  <input id="bairro" name="bairro" required className={field} />
                </div>
                <div className="md:col-span-3">
                  <label className={label} htmlFor="comp">Complemento</label>
                  <input id="comp" name="comp" className={field} />
                </div>
              </div>
            )}
          </fieldset>

          <fieldset>
            <legend className="display text-3xl">03 Pagamento</legend>
            <div className="mt-5 grid gap-3 md:grid-cols-3">
              {(
                [
                  ["pix", "Pix", "Chave enviada após o pedido"],
                  ["cartao", "Cartão", "Em até 12x, pagamento seguro"],
                  ...(delivery === "motoboy"
                    ? [["entrega", "Na entrega", "Pague só quando receber"]]
                    : []),
                ] as [Pay, string, string][]
              ).map(([v, t, d]) => (
                <button
                  type="button"
                  key={v}
                  onClick={() => setPay(v)}
                  aria-pressed={pay === v}
                  className={`border rule p-4 text-left transition-colors ${
                    pay === v ? "bg-ink text-paper" : "hover:bg-bone"
                  }`}
                >
                  <span className="block text-[15px] font-medium">{t}</span>
                  <span className={`mono block text-[12px] ${pay === v ? "text-paper/70" : "text-stone"}`}>
                    {d}
                  </span>
                </button>
              ))}
            </div>
            <p className="mono mt-3 text-[12px] text-stone">
              Dados de cartão nunca são digitados neste site: o pagamento
              acontece no ambiente do gateway.
            </p>
          </fieldset>
        </div>

        <aside className="md:sticky md:top-24 md:self-start">
          <div className="border rule p-5">
            <h2 className="display text-3xl">Resumo</h2>
            <ul className="mt-4 divide-y divide-ink/15">
              {lines.map((l) => (
                <li key={l.slug + l.size} className="flex gap-3 py-3">
                  <img src={imgUrl(l.product.image)} alt="" className="h-20 w-16 shrink-0 bg-bone object-cover" />
                  <div className="flex-1 text-[14px]">
                    <p className="leading-snug">{l.product.name}</p>
                    <p className="mono mt-1 text-[12px] text-stone">
                      Tam. {l.size} · {l.qty}x
                    </p>
                  </div>
                  <span className="mono text-[13px]">{money(l.product.price * l.qty)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex items-baseline justify-between border-t rule pt-4">
              <span className="text-[13px] uppercase tracking-[0.18em]">Total</span>
              <span className="mono text-2xl font-semibold">{money(subtotal)}</span>
            </div>
            <button
              type="submit"
              className="mt-5 w-full bg-ink py-4 text-[13px] uppercase tracking-[0.22em] text-paper transition-colors hover:bg-signal"
            >
              Confirmar pedido
            </button>
          </div>
        </aside>
      </form>
    </div>
  );
}
