import { Link } from "react-router-dom";
import { ProductCard } from "../components/ProductCard";
import { Ticker } from "../components/Ticker";
import { categories, imgUrl, products } from "../data/products";
import { STORE, contactLabel, contactUrl, mapsUrl } from "../lib/store";
import heroStrip from "../assets/img/hero.jpg";

export default function Home() {
  const lead = products.filter((p) => p.isNew);
  const rest = products.filter((p) => !p.isNew);
  const count = (id: string) => products.filter((p) => p.category === id).length;

  return (
    <>
      {/* HERO */}
      <section className="mx-auto max-w-[1400px] px-5 pb-10 pt-8 md:px-8 md:pt-14">
        <div className="grid items-end gap-10 md:grid-cols-[1.25fr_1fr] md:gap-14">
          <div className="rise">
            <p className="mono text-[12px] uppercase tracking-[0.2em] text-stone">
              Loja física e on-line · São Paulo
            </p>
            <h1 className="display mt-4 text-[clamp(4.4rem,17.5vw,12.5rem)] md:text-[clamp(5rem,9.4vw,9rem)]">
              Original
              <br />
              <span className="italic text-signal">de verdade.</span>
            </h1>
            <p className="mt-6 max-w-md text-[17px] leading-relaxed text-ink/75">
              Nike, Tommy Hilfiger, Adidas, Puma. Você escolhe, a gente entrega
              por motoboy e você paga só quando receber.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/loja"
                className="bg-ink px-7 py-4 text-[13px] uppercase tracking-[0.2em] text-paper transition-colors hover:bg-signal"
              >
                Ver a coleção
              </Link>
              <a
                href={contactUrl("Oi! Vim pelo site da JN Originals.")}
                target="_blank"
                rel="noreferrer"
                className="border rule px-7 py-4 text-[13px] uppercase tracking-[0.2em] transition-colors hover:bg-ink hover:text-paper"
              >
                Falar no {contactLabel}
              </a>
            </div>
          </div>

          <div
            className="rise mx-auto grid aspect-[5/6] w-full max-w-[520px] grid-cols-3 grid-rows-3 gap-2 md:gap-3"
            style={{ animationDelay: "0.15s" }}
          >
            <img
              src={imgUrl("nike")}
              alt="Tênis Nike Court Borough Low"
              className="col-span-2 row-span-2 h-full w-full bg-bone object-cover"
            />
            <img
              src={imgUrl("bone")}
              alt="Boné Puma BMW"
              className="h-full w-full bg-bone object-cover"
            />
            <img
              src={imgUrl("polo")}
              alt="Polo Tommy Hilfiger"
              className="h-full w-full bg-bone object-cover object-top"
            />
            <img
              src={imgUrl("jaqueta")}
              alt="Jaqueta Adidas Argentina"
              className="col-span-2 h-full w-full bg-bone object-cover object-top"
            />
            <div className="flex flex-col justify-between bg-ink p-3 text-paper">
              <span className="mono text-[11px] uppercase leading-tight">
                100%
                <br />
                original
              </span>
              <span className="display text-5xl italic">JN</span>
            </div>
          </div>
        </div>
      </section>

      <Ticker />

      {/* CATEGORIAS */}
      <section className="mx-auto max-w-[1400px] px-5 py-16 md:px-8 md:py-24">
        <SectionHead n="01" title="Escolha por categoria" />
        <ul className="mt-8 border-t rule">
          {categories.map((c, i) => (
            <li key={c.id} className="border-b rule">
              <Link
                to={`/loja?cat=${c.id}`}
                className="group flex items-baseline justify-between gap-4 py-4 transition-[padding] duration-300 hover:pl-3 md:py-5"
              >
                <span className="flex items-baseline gap-4 md:gap-8">
                  <span className="mono text-xs text-stone">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="display text-[clamp(2.3rem,7.4vw,6rem)] transition-colors group-hover:text-signal">
                    {c.label}
                  </span>
                </span>
                <span className="mono shrink-0 whitespace-nowrap text-[12px] uppercase tracking-wider text-stone">
                  {count(c.id)} {count(c.id) === 1 ? "item" : "itens"} →
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* LANÇAMENTOS */}
      <section className="mx-auto max-w-[1400px] px-5 md:px-8">
        <div className="flex items-end justify-between gap-6">
          <SectionHead n="02" title="Lançamentos" />
          <Link
            to="/loja"
            className="hidden text-[13px] uppercase tracking-[0.18em] underline underline-offset-[10px] md:block"
          >
            Ver tudo
          </Link>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 md:gap-x-6">
          {lead.map((p, i) => (
            <ProductCard key={p.slug} p={p} index={i} />
          ))}
        </div>
      </section>

      {/* FAIXA PUMA */}
      <section className="mt-20 md:mt-28">
        <div className="relative overflow-hidden bg-ink">
          <img
            src={heroStrip}
            alt="Linha Puma Motorsport"
            className="h-[300px] w-full object-cover opacity-80 grayscale md:h-[460px]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 mx-auto flex max-w-[1400px] items-end justify-between gap-6 px-5 pb-6 text-paper md:px-8 md:pb-10">
            <div>
              <p className="mono text-[11px] uppercase tracking-[0.2em] text-paper/70">
                Linha especial
              </p>
              <h2 className="display text-[clamp(3rem,11vw,8rem)]">
                Puma <span className="italic text-signal">Motorsport</span>
              </h2>
            </div>
            <Link
              to="/loja?cat=acessorios"
              className="mb-2 hidden border border-paper/70 px-6 py-3 text-[13px] uppercase tracking-[0.2em] transition-colors hover:bg-paper hover:text-ink md:block"
            >
              Ver peças
            </Link>
          </div>
        </div>
      </section>

      {/* MAIS PEÇAS */}
      <section className="mx-auto max-w-[1400px] px-5 pt-20 md:px-8 md:pt-28">
        <SectionHead n="03" title="Mais peças" />
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
          {rest.map((p, i) => (
            <ProductCard key={p.slug} p={p} index={lead.length + i} />
          ))}
        </div>
      </section>

      {/* CONFIANÇA */}
      <section className="mx-auto max-w-[1400px] px-5 pt-20 md:px-8 md:pt-28">
        <SectionHead n="04" title="Por que comprar na JN" />
        <div className="mt-8 grid border-l border-t rule md:grid-cols-4">
          {[
            {
              t: "Loja física",
              d: `${STORE.address}, ${STORE.city}. ${STORE.hours}.`,
            },
            {
              t: "Pague quando receber",
              d: "Nas entregas por motoboy, o pagamento é no ato da entrega.",
            },
            {
              t: "Empresa registrada",
              d: `${STORE.legalName}, CNPJ ${STORE.cnpj}.`,
            },
            {
              t: "Atendimento direto",
              d: `Tire dúvidas de tamanho e disponibilidade pelo ${contactLabel}.`,
            },
          ].map((b, i) => (
            <div key={b.t} className="border-b border-r rule p-6 md:min-h-[220px]">
              <span className="mono text-xs text-stone">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="display mt-6 text-[2.2rem]">{b.t}</h3>
              <p className="mt-3 text-[15px] leading-relaxed text-ink/70">{b.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* VISITE */}
      <section className="mx-auto max-w-[1400px] px-5 pt-20 md:px-8 md:pt-28">
        <div className="grid gap-8 bg-ink p-7 text-paper md:grid-cols-[1.3fr_1fr] md:p-14">
          <div>
            <p className="mono text-[11px] uppercase tracking-[0.2em] text-stone">
              Venha provar
            </p>
            <h2 className="display mt-4 text-[clamp(3rem,9vw,7rem)]">
              Passa na <span className="italic text-signal">loja.</span>
            </h2>
          </div>
          <div className="flex flex-col justify-end gap-5">
            <p className="text-[17px] leading-relaxed text-paper/80">
              {STORE.address}
              <br />
              {STORE.city}
              <br />
              {STORE.hours}
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href={mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="bg-paper px-6 py-3 text-[13px] uppercase tracking-[0.18em] text-ink transition-colors hover:bg-signal hover:text-paper"
              >
                Como chegar
              </a>
              <Link
                to="/a-loja"
                className="border border-paper/60 px-6 py-3 text-[13px] uppercase tracking-[0.18em] transition-colors hover:bg-paper hover:text-ink"
              >
                Sobre a loja
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function SectionHead({ n, title }: { n: string; title: string }) {
  return (
    <div className="flex items-baseline gap-4">
      <span className="mono text-sm text-stone">({n})</span>
      <h2 className="display text-[clamp(2.3rem,6vw,4.2rem)] leading-[0.98]">{title}</h2>
    </div>
  );
}
