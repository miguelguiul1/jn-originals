import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Logo } from "./Logo";
import { useCart } from "../lib/cart";

const links = [
  { to: "/loja", label: "Loja" },
  { to: "/como-comprar", label: "Como comprar" },
  { to: "/a-loja", label: "A loja" },
];

export function Header() {
  const { count, setOpen } = useCart();
  const [menu, setMenu] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setMenu(false);
  }, [pathname]);
  useEffect(() => {
    document.documentElement.style.overflow = menu ? "hidden" : "";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [menu]);

  return (
    <>
      <header className="sticky top-0 z-40 border-b rule bg-paper/92 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-5 md:px-8">
          <Link to="/" aria-label="JN Originals, página inicial">
            <Logo />
          </Link>

          <nav className="hidden items-center gap-9 md:flex">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  `text-[13px] uppercase tracking-[0.18em] underline-offset-[10px] hover:underline ${
                    isActive ? "underline" : ""
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setOpen(true)}
              className="flex h-10 items-center gap-2 border rule px-3 text-[13px] uppercase tracking-[0.16em] transition-colors hover:bg-ink hover:text-paper"
              aria-label={`Abrir sacola, ${count} itens`}
            >
              Sacola
              <span className="mono grid min-w-5 place-items-center bg-ink px-1 text-[11px] text-paper">
                {count}
              </span>
            </button>
            <button
              onClick={() => setMenu(true)}
              className="grid h-10 w-10 place-items-center border rule md:hidden"
              aria-label="Abrir menu"
            >
              <span className="block w-4 space-y-[5px]">
                <span className="block h-px bg-ink" />
                <span className="block h-px bg-ink" />
              </span>
            </button>
          </div>
        </div>
      </header>

      {menu && (
        <div className="fixed inset-0 z-50 flex flex-col bg-ink px-5 pb-8 pt-4 text-paper md:hidden">
          <div className="flex h-12 items-center justify-between">
            <Logo />
            <button
              onClick={() => setMenu(false)}
              className="text-[13px] uppercase tracking-[0.18em]"
            >
              Fechar
            </button>
          </div>
          <nav className="mt-10 flex flex-1 flex-col gap-2">
            {[{ to: "/", label: "Início" }, ...links].map((l, i) => (
              <Link
                key={l.to}
                to={l.to}
                className="display flex items-baseline gap-4 border-b border-paper/20 py-3 text-[3.4rem]"
              >
                <span className="mono text-xs text-stone">0{i + 1}</span>
                {l.label}
              </Link>
            ))}
          </nav>
          <p className="text-[11px] uppercase tracking-[0.2em] text-stone">
            Seg a sáb · 9h às 20h
          </p>
        </div>
      )}
    </>
  );
}
