import { Link } from "react-router-dom";
import { discountPct, imgUrl, type Product } from "../data/products";
import { money } from "../lib/store";

export function ProductCard({
  p,
  index,
  className = "",
}: {
  p: Product;
  index?: number;
  className?: string;
}) {
  const off = discountPct(p);
  return (
    <Link
      to={`/produto/${p.slug}`}
      className={`group block ${className}`}
      aria-label={p.name}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-bone">
        <img
          src={imgUrl(p.image)}
          alt={p.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
        />
        <div className="absolute left-0 top-0 flex flex-col items-start gap-1">
          {index !== undefined && (
            <span className="mono bg-ink px-2 py-1 text-[11px] text-paper">
              {String(index + 1).padStart(2, "0")}
            </span>
          )}
          {off > 0 && (
            <span className="mono bg-signal px-2 py-1 text-[11px] text-paper">
              −{off}%
            </span>
          )}
          {p.isNew && !off && (
            <span className="mono border-b border-r rule bg-paper px-2 py-1 text-[11px]">
              Novo
            </span>
          )}
        </div>
      </div>

      <div className="mt-3">
        <p className="mono truncate text-[11px] uppercase text-stone">
          {p.brand} · {p.code}
        </p>
        <h3 className="mt-1 text-[15px] font-medium leading-snug">{p.name}</h3>
        <p className="mono mt-2 flex flex-wrap items-baseline gap-x-2 text-[15px] font-semibold">
          {money(p.price)}
          {p.oldPrice && (
            <span className="text-[11px] font-normal text-stone line-through">
              {money(p.oldPrice)}
            </span>
          )}
        </p>
        <p className="mono mt-0.5 text-[11px] text-stone">
          12x de {money(p.installment)}
        </p>
      </div>
    </Link>
  );
}
