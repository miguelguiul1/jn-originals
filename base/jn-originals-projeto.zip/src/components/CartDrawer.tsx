import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useCart } from "../lib/cart";
import { imgUrl } from "../data/products";
import { money } from "../lib/store";

export function CartDrawer() {
  const { open, setOpen, lines, subtotal, setQty, remove, count } = useCart();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setOpen]);

  return (
    <div
      className={`fixed inset-0 z-[60] ${open ? "" : "pointer-events-none"}`}
      aria-hidden={!open}
    >
      <div
        onClick={() => setOpen(false)}
        className={`absolute inset-0 bg-ink/55 transition-opacity duration-300 ${
          open ? "opacity-100" : "opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-label="Sacola"
        className={`absolute right-0 top-0 flex h-full w-full max-w-[440px] flex-col bg-paper transition-transform duration-500 ease-[cubic-bezier(0.77,0,0.18,1)] ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b rule px-5">
          <h2 className="display text-3xl">
            Sacola <span className="mono text-base text-stone">({count})</span>
          </h2>
          <button
            onClick={() => setOpen(false)}
            className="text-[13px] uppercase tracking-[0.18em]"
          >
            Fechar
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5">
          {lines.length === 0 ? (
            <div className="py-16">
              <p className="display text-5xl">Sacola vazia.</p>
              <p className="mt-4 max-w-xs text-[15px] text-stone">
                Escolha um tênis, uma jaqueta ou uma polo e volte aqui para
                fechar o pedido.
              </p>
              <Link
                to="/loja"
                onClick={() => setOpen(false)}
                className="mt-8 inline-block border rule bg-ink px-6 py-3 text-[13px] uppercase tracking-[0.18em] text-paper"
              >
                Ver a loja
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-ink/15">
              {lines.map((l) => (
                <li key={l.slug + l.size} className="flex gap-4 py-5">
                  <img
                    src={imgUrl(l.product.image)}
                    alt=""
                    className="h-28 w-[88px] shrink-0 bg-bone object-cover"
                  />
                  <div className="flex min-w-0 flex-1 flex-col">
                    <p className="mono text-[11px] uppercase text-stone">
                      {l.product.brand}
                    </p>
                    <p className="text-[15px] font-medium leading-snug">
                      {l.product.name}
                    </p>
                    <p className="mono mt-1 text-[12px]">Tam. {l.size}</p>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="flex items-center border rule">
                        <button
                          className="h-8 w-8"
                          onClick={() => setQty(l.slug, l.size, l.qty - 1)}
                          aria-label="Diminuir"
                        >
                          −
                        </button>
                        <span className="mono w-6 text-center text-[13px]">
                          {l.qty}
                        </span>
                        <button
                          className="h-8 w-8"
                          onClick={() => setQty(l.slug, l.size, l.qty + 1)}
                          aria-label="Aumentar"
                        >
                          +
                        </button>
                      </div>
                      <span className="mono text-[14px] font-semibold">
                        {money(l.product.price * l.qty)}
                      </span>
                    </div>
                    <button
                      onClick={() => remove(l.slug, l.size)}
                      className="mt-2 self-start text-[11px] uppercase tracking-[0.16em] text-stone underline underline-offset-4"
                    >
                      Remover
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <div className="border-t rule px-5 pb-6 pt-4">
            <div className="flex items-baseline justify-between">
              <span className="text-[13px] uppercase tracking-[0.18em]">
                Subtotal
              </span>
              <span className="mono text-xl font-semibold">{money(subtotal)}</span>
            </div>
            <p className="mono mt-1 text-[11px] text-stone">
              Entrega combinada com a loja no fechamento.
            </p>
            <Link
              to="/finalizar"
              onClick={() => setOpen(false)}
              className="mt-4 block bg-ink py-4 text-center text-[13px] uppercase tracking-[0.2em] text-paper transition-colors hover:bg-signal"
            >
              Finalizar pedido
            </Link>
          </div>
        )}
      </aside>
    </div>
  );
}
