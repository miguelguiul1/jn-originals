import { Link } from "react-router-dom";
import { STORE, contactLabel, contactUrl, mapsUrl } from "../lib/store";

export function Footer() {
  return (
    <footer className="mt-24 bg-ink text-paper">
      <div className="mx-auto grid max-w-[1400px] gap-12 px-5 pb-10 pt-16 md:grid-cols-[1.4fr_1fr_1fr_1fr] md:px-8">
        <div>
          <p className="display text-[2.6rem] leading-[0.9]">
            Apenas produtos
            <br />
            originais.
          </p>
          <p className="mt-5 max-w-xs text-[15px] text-paper/65">
            Nike, Tommy Hilfiger, Adidas, Puma e mais. Loja física em São Paulo
            e entrega por motoboy.
          </p>
        </div>

        <FooterCol title="Loja">
          <Link to="/loja">Todos os produtos</Link>
          <Link to="/loja?cat=calcados">Calçados</Link>
          <Link to="/loja?cat=jaquetas">Jaquetas e blusões</Link>
          <Link to="/loja?cat=acessorios">Acessórios</Link>
        </FooterCol>

        <FooterCol title="Ajuda">
          <Link to="/como-comprar">Como comprar</Link>
          <Link to="/a-loja">A loja</Link>
          <a href={contactUrl()} target="_blank" rel="noreferrer">
            {contactLabel}
          </a>
          <a href={STORE.instagramUrl} target="_blank" rel="noreferrer">
            Instagram
          </a>
        </FooterCol>

        <FooterCol title="Visite">
          <span>{STORE.address}</span>
          <span>{STORE.city}</span>
          <span>{STORE.hours}</span>
          <a href={mapsUrl} target="_blank" rel="noreferrer" className="underline">
            Abrir no mapa
          </a>
        </FooterCol>
      </div>

      <div className="mx-auto max-w-[1400px] px-5 md:px-8">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-paper/20 py-5 text-[12px] text-paper/60">
          <span>
            {STORE.legalName} · CNPJ {STORE.cnpj}
          </span>
          <span className="mono">Pix · Cartão em até 12x</span>
          <span>Compra segura</span>
        </div>
      </div>

      <div
        className="display select-none overflow-hidden whitespace-nowrap text-center italic leading-[0.74] text-paper/[0.07] text-[clamp(8rem,34vw,34rem)]"
        aria-hidden
      >
        JN
      </div>

      <div className="bg-signal px-5 py-2 text-center text-[11px] uppercase tracking-[0.18em] text-paper">
        Protótipo de proposta · não é a loja oficial · nenhum pagamento é
        processado
      </div>
    </footer>
  );
}

function FooterCol({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h4 className="mono text-[11px] uppercase tracking-[0.2em] text-stone">
        {title}
      </h4>
      <div className="mt-4 flex flex-col gap-2 text-[15px] [&_a:hover]:underline">
        {children}
      </div>
    </div>
  );
}
