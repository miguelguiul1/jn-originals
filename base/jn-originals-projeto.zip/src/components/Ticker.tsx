const items = [
  "Apenas produtos originais",
  "Pague só quando receber",
  "Seg a sáb · 9h às 20h",
  "Loja física em São Paulo",
  "Em até 12x no cartão",
  "Pix",
];

export function Ticker({ dark = false }: { dark?: boolean }) {
  const row = [...items, ...items];
  return (
    <div
      className={`overflow-hidden border-y rule py-3 ${
        dark ? "bg-ink text-paper" : "bg-bone"
      }`}
      aria-hidden
    >
      <div className="ticker-track">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center">
            {row.map((t, i) => (
              <span
                key={i}
                className="display flex items-center gap-8 pr-8 text-[1.35rem] tracking-[0.04em]"
              >
                {t}
                <span className="h-[7px] w-[7px] rotate-45 bg-signal" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
