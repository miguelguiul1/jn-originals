export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-end gap-2 leading-none ${className}`}>
      <span className="display text-[34px] italic">JN</span>
      <span className="mb-[3px] flex flex-col gap-[3px]">
        <span className="h-px w-full bg-current" />
        <span className="display text-[11px] tracking-[0.32em]">Originals</span>
      </span>
    </span>
  );
}
