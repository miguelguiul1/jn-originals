import { useEffect, useRef, useState } from "react";

const SEEN = "jn-intro-seen";

function alreadySeen() {
  try {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return true;
    return sessionStorage.getItem(SEEN) === "1";
  } catch {
    return false;
  }
}

const DURATION = 2400;

/**
 * Abertura em tela cheia: nome da marca sobe letra por letra, contador
 * de 000 a 100 e a cortina sobe revelando a loja. Aparece uma vez por visita.
 */
export function Intro() {
  const [mounted, setMounted] = useState(() => !alreadySeen());
  const [leaving, setLeaving] = useState(false);
  const [n, setN] = useState(0);
  const raf = useRef(0);

  const finish = () => {
    if (leaving) return;
    setLeaving(true);
    try {
      sessionStorage.setItem(SEEN, "1");
    } catch {
      /* ignora */
    }
    window.setTimeout(() => setMounted(false), 950);
  };

  useEffect(() => {
    if (!mounted) return;
    document.documentElement.style.overflow = "hidden";
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / DURATION);
      // ease-out suave para o contador
      setN(Math.round((1 - Math.pow(1 - p, 2.2)) * 100));
      if (p < 1) raf.current = requestAnimationFrame(tick);
      else window.setTimeout(finish, 350);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf.current);
      document.documentElement.style.overflow = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted]);

  useEffect(() => {
    if (!mounted) document.documentElement.style.overflow = "";
  }, [mounted]);

  if (!mounted) return null;

  const letter = (ch: string, i: number) => (
    <span key={i} className="inline-block overflow-hidden px-[0.06em] align-bottom">
      <span
        className="inline-block"
        style={{
          animation: `letter-up 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) ${
            0.15 + i * 0.12
          }s both`,
        }}
      >
        {ch}
      </span>
    </span>
  );

  return (
    <div
      role="dialog"
      aria-label="Abertura"
      className="fixed inset-0 z-[100] flex flex-col justify-between bg-ink px-5 pb-6 pt-5 text-paper"
      style={{
        transform: leaving ? "translateY(-100%)" : "translateY(0)",
        transition: "transform 0.95s cubic-bezier(0.77, 0, 0.18, 1)",
      }}
    >
      <div className="flex items-start justify-between text-[11px] uppercase tracking-[0.22em]">
        <span style={{ animation: "fade-in 0.8s 0.2s both" }}>
          Loja física e on-line
        </span>
        <button
          onClick={finish}
          className="uppercase tracking-[0.22em] underline-offset-4 hover:underline"
          style={{ animation: "fade-in 0.8s 0.6s both" }}
        >
          Pular
        </button>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center">
        <div
          className="display italic leading-[0.8] text-[clamp(9rem,46vw,26rem)]"
          aria-label="JN"
        >
          {["J", "N"].map(letter)}
        </div>
        <div
          className="mt-3 flex w-[min(78vw,520px)] items-center gap-4"
          style={{ animation: "fade-in 0.8s 0.9s both" }}
        >
          <span
            className="h-px flex-1 origin-left bg-paper/70"
            style={{ animation: "draw 1.1s 0.9s cubic-bezier(0.2,0.8,0.2,1) both" }}
          />
          <span className="display text-[clamp(1rem,3.6vw,1.6rem)] tracking-[0.42em]">
            Originals
          </span>
          <span
            className="h-px flex-1 origin-right bg-paper/70"
            style={{ animation: "draw 1.1s 0.9s cubic-bezier(0.2,0.8,0.2,1) both" }}
          />
        </div>
      </div>

      <div className="flex items-end justify-between">
        <span
          className="display text-[clamp(3rem,12vw,6rem)] tabular-nums"
          aria-hidden
        >
          {String(n).padStart(3, "0")}
        </span>
        <span
          className="max-w-[11rem] text-right text-[11px] uppercase leading-snug tracking-[0.22em]"
          style={{ animation: "fade-in 0.8s 1.2s both" }}
        >
          Apenas produtos originais
          <span className="mt-1 block text-signal">São Paulo</span>
        </span>
      </div>
    </div>
  );
}
