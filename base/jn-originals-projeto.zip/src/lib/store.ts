// Dados da loja (fonte: Instagram, Linktree e rodapé do site atual).
export const STORE = {
  name: "JN Originals",
  legalName: "JN Originals LTDA",
  cnpj: "49.009.219/0001-40",
  address: "Rua Pasquale Gallupi, 1280",
  city: "São Paulo, SP",
  hours: "Segunda a sábado, das 9h às 20h",
  instagram: "jnoriginals01",
  instagramUrl: "https://www.instagram.com/jnoriginals01/",
  // Preencher com o número real, só dígitos com DDI: ex. "5511999999999".
  // Vazio = os botões levam ao Direct do Instagram.
  whatsapp: "",
};

export const mapsUrl =
  "https://www.google.com/maps/search/?api=1&query=" +
  encodeURIComponent(`${STORE.address}, ${STORE.city}`);

export function contactUrl(message?: string) {
  if (STORE.whatsapp) {
    const q = message ? `?text=${encodeURIComponent(message)}` : "";
    return `https://wa.me/${STORE.whatsapp}${q}`;
  }
  return `https://ig.me/m/${STORE.instagram}`;
}

export const contactLabel = STORE.whatsapp ? "WhatsApp" : "Direct";

const brl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});
export const money = (v: number) => brl.format(v);
