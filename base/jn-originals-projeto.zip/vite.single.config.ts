import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";

// Gera um único HTML (fontes e fotos embutidas) só para pré-visualizar.
export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss(), viteSingleFile()],
  build: { outDir: "dist-preview", assetsInlineLimit: 100_000_000 },
});
